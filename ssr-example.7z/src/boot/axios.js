import axios from 'axios'
import { inject } from './helpers'

export default inject((_) => {
  return {
    axios: axios.create()
  }
})
