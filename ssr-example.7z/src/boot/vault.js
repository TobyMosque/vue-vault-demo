// import something here
import Vue from 'vue'
import { inject } from './helpers'

// "async" is optional;
// more info on params: https://quasar.dev/quasar-cli/boot-files
export default inject(async ({ ssrContext }) => {
  const vault = {}
  if (!ssrContext) {
    const data = window.__VAULT_STATE__
    const keys = Object.keys(data)
    for (const key of keys) {
      vault[key] = create({ data: data[key] })
    }
  }
  if (ssrContext) {
    ssrContext.rendered = () => {
      ssrContext.vaultState = JSON.stringify(vault)
    }
  }
  return {
    vault: vault
  }
})

export function create ({ data }) {
  let state = Vue.observable(typeof data === 'function' ? data() : data)
  if (typeof state === 'function') {
    state = state()
  }
  return state
}

export function page ({ namespace, data, destroyed, preFetch, ...options }) {
  return {
    async preFetch (context) {
      const { store } = context
      if (!store.$vault[namespace]) {
        context.data = create({ data })
        context.axios = store.$axios
        store.$vault[namespace] = context.data
        if (preFetch) {
          await preFetch(context)
        }
      }
    },
    data () {
      return this.$vault[namespace]
    },
    destroyed () {
      delete this.$vault[namespace]
    },
    ...options
  }
}
