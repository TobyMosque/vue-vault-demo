<template>
  <q-page class="flex flex-center">
    {{uid}}
  </q-page>
</template>

<script>
import { page } from 'src/boot/vault'
import { uid } from 'quasar'

export default page({
  namespace: 'page-index',
  name: 'PageIndex',
  async preFetch ({ data, axios, store, currentRoute, redirect }) {
    await new Promise(resolve => setTimeout(resolve, 1000))
    console.log({ axios, store, currentRoute, redirect })
    data.uid = uid()
  },
  data () {
    return {
      uid: ''
    }
  },
  mounted () {
    console.log(this.$vault)
  }
})
</script>
